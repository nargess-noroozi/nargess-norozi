import tkinter as tk
from tkinter import messagebox

def get_precedence(op):
    if op in ('+', '-'):
        return 1
    if op in ('*', '/'):
        return 2
    return 0

def infix_to_postfix(infix):
    operators = []
    postfix = ""

    for ch in infix:
        if ch.isalnum():  # چک کردن اگر حرف یا عدد باشد
            postfix += ch
        elif ch == '(':
            operators.append(ch)
        elif ch == ')':
            while operators and operators[-1] != '(':
                postfix += operators.pop()
            operators.pop()
        else:
            while operators and get_precedence(operators[-1]) >= get_precedence(ch):
                postfix += operators.pop()
            operators.append(ch)

    while operators:
        postfix += operators.pop()

    return postfix

def postfix_to_infix(postfix):
    operands = []

    for ch in postfix:
        if ch.isalnum():
            operands.append(ch)
        else:
            op1 = operands.pop()
            op2 = operands.pop()
            expr = f"({op2}{ch}{op1})"
            operands.append(expr)

    return operands[-1]

# رابط کاربری
def convert_to_postfix():
    infix = entry_infix.get()
    try:
        postfix = infix_to_postfix(infix)
        entry_result.delete(0, tk.END)
        entry_result.insert(0, postfix)
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {str(e)}")

def convert_to_infix():
    postfix = entry_infix.get()
    try:
        infix = postfix_to_infix(postfix)
        entry_result.delete(0, tk.END)
        entry_result.insert(0, infix)
    except Exception as e:
        messagebox.showerror("Error", f"An error occurred: {str(e)}")

# تنظیمات پنجره
root = tk.Tk()
root.title("نرگس نوروزی-140122028087")

label_infix = tk.Label(root, text="Enter Infix/Postfix Expression:")
label_infix.pack()

entry_infix = tk.Entry(root, width=30)
entry_infix.pack()

button_postfix = tk.Button(root, text="Convert to Postfix", command=convert_to_postfix)
button_postfix.pack()

button_infix = tk.Button(root, text="Convert to Infix", command=convert_to_infix)
button_infix.pack()

label_result = tk.Label(root, text="Result:")
label_result.pack()

entry_result = tk.Entry(root, width=30)
entry_result.pack()

# اجرا
root.mainloop()
