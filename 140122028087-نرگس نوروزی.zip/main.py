import tkinter as tk
from tkinter import messagebox

# تابع برای بررسی اولویت اپراتورها
def get_precedence(op):
    if op in ('+', '-'):
        return 1
    if op in ('*', '/'):
        return 2
    return 0

# توابع تبدیل
def infix_to_postfix(infix):
    operators = []
    postfix = ""
    for ch in infix:
        if ch.isalnum():
            postfix += ch
        elif ch == '(':
            operators.append(ch)
        elif ch == ')':
            while operators and operators[-1] != '(':
                postfix += operators.pop()
            operators.pop()
        else:
            while operators and get_precedence(operators[-1]) >= get_precedence(ch):
                postfix += operators.pop()
            operators.append(ch)
    while operators:
        postfix += operators.pop()
    return postfix

def postfix_to_infix(postfix):
    operands = []
    for ch in postfix:
        if ch.isalnum():
            operands.append(ch)
        else:
            op1 = operands.pop()
            op2 = operands.pop()
            expr = f"({op2}{ch}{op1})"
            operands.append(expr)
    return operands[-1]

def infix_to_prefix(infix):
    reversed_expr = infix[::-1]
    reversed_expr = reversed_expr.replace('(', ')_').replace(')', '(').replace(')_', '(')
    reversed_postfix = infix_to_postfix(reversed_expr)
    return reversed_postfix[::-1]

def prefix_to_infix(prefix):
    operands = []
    for ch in reversed(prefix):
        if ch.isalnum():
            operands.append(ch)
        else:
            op1 = operands.pop()
            op2 = operands.pop()
            expr = f"({op1}{ch}{op2})"
            operands.append(expr)
    return operands[-1]

# تابع اصلی تبدیل
def convert_expression():
    expr = entry_expression.get()
    from_type = from_var.get()
    to_type = to_var.get()
    
    try:
        if from_type == "Infix" and to_type == "Postfix":
            result = infix_to_postfix(expr)
        elif from_type == "Infix" and to_type == "Prefix":
            result = infix_to_prefix(expr)
        elif from_type == "Postfix" and to_type == "Infix":
            result = postfix_to_infix(expr)
        elif from_type == "Prefix" and to_type == "Infix":
            result = prefix_to_infix(expr)
        else:
            result = "نوع تبدیل نامعتبر است."
        
        entry_result.delete(0, tk.END)
        entry_result.insert(0, result)
    except Exception as e:
        messagebox.showerror("خطا", f"خطا در تبدیل: {str(e)}")

# تنظیمات پنجره
root = tk.Tk()
root.title("نرگس نوروزی-140122028087")
root.geometry("400x400")


# تنظیمات رادیو دکمه‌ها
from_var = tk.StringVar(value="Infix")
to_var = tk.StringVar(value="Postfix")

tk.Label(root, text="تبدیل از:").grid(row=0, column=0, padx=10, pady=5)
tk.Radiobutton(root, text="Infix", variable=from_var, value="Infix").grid(row=0, column=1)
tk.Radiobutton(root, text="Postfix", variable=from_var, value="Postfix").grid(row=0, column=2)
tk.Radiobutton(root, text="Prefix", variable=from_var, value="Prefix").grid(row=0, column=3)

tk.Label(root, text="به:").grid(row=1, column=0, padx=10, pady=5)
tk.Radiobutton(root, text="Infix", variable=to_var, value="Infix").grid(row=1, column=1)
tk.Radiobutton(root, text="Postfix", variable=to_var, value="Postfix").grid(row=1, column=2)
tk.Radiobutton(root, text="Prefix", variable=to_var, value="Prefix").grid(row=1, column=3)

# ورودی عبارت
tk.Label(root, text="عبارت را وارد کنید:").grid(row=2, column=0, columnspan=4, padx=10, pady=5)
entry_expression = tk.Entry(root, width=30)
entry_expression.grid(row=3, column=0, columnspan=4, padx=10, pady=5)

# دکمه تبدیل
button_convert = tk.Button(root, text="تبدیل", command=convert_expression)
button_convert.grid(row=4, column=0, columnspan=4, padx=10, pady=5)

# نمایش نتیجه
tk.Label(root, text="نتیجه:").grid(row=5, column=0, columnspan=4, padx=10, pady=5)
entry_result = tk.Entry(root, width=30)
entry_result.grid(row=6, column=0, columnspan=4, padx=10, pady=5)


tk.Label(root, text="نرگس نوروزی-140122028087").grid(row=10, column=0, columnspan=4, padx=10, pady=5)

# اجرا
root.mainloop()
